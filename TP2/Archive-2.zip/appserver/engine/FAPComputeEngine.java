package engine;

public class FAPComputeEngine extends ComputeEngineNotifier {

	public FAPComputeEngine() {
		super();
	}
	
	@SuppressWarnings("unchecked")
	public void run() {
		while(true) {
			try {
				Thread.sleep(20);
				
				
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
}
