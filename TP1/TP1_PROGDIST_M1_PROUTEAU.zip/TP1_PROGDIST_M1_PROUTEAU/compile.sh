#!/usr/bin/env bash

javac -source 8 -target 8 -cp openjms-0.7.7-beta-1/lib/jms-1.1.jar Archive/journal/*.java Archive/journaltest/*.java